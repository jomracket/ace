
===========================================================
ace - l'emulatore candeggina - serious readme file (almost)
===========================================================

======================================
things you should know before going on
======================================

- You are not allowed to sell/ask money for this emulator.
- You are not allowed to modify in any way the files included with this emulator.
- You are not allowed to distribute this emulator along with ROMS.
- I can NOT be hold responsible if you violate any of the above terms 
  or for any damage to your system. By the way, if you manage to damage your
  system with ace, let me know how you did it.

===============================
what is this, what is emulation
===============================

ace is an emulator. an emulator is nothing else than a normal program that
reproduces (more or less) exactly the inner workings of the chips you find in
some arcade systems, CPS1, CPS2, Neogeo, System 16 and System 18 in particular.
this means that ace is capable of "emulating" for example the Motorola 68000
cpu, or the Zilog 80 processor, and so on, at instruction level.
moreover, ace emulates the sound, video and controller components of this hardware.
one (nice) side effect of this is that if you give to it the original program, graphic
and sound sample "roms" of some game, you will see on your pc
the game running as it was on the cabinet of the arcade near your home.

but you already knew all of this, you just wanted to play marvel vz. capcom or
metal slug 3. so here it is how.

====================
general requirements
====================

Needed:

A Pentium (tm) class processor.
Any version of Microsoft (c) Windows (tm) (except 3.1 or lesser, please!).
Microsoft Direct X (c) 3.0 or better (tm).

Preferred:

A Pentium (tm) III class processor.
Microsoft Windows (many "(c)"s) 98.
A sound card.

================================================
how do I play [place your favourite game here] ?
================================================

Unzip the emulator in one folder.
Now open the "ace.ini" file with the windows notepad.
Under the "[general]" section you should see a line like this:

rompath=d:\emul\romz\arcade\

Ok, modify this line in order for the emulator to find the folder where you have the game
roms (notice that the roms must be zipped). For example, if you have them in the 
"c:\r00mz\wareZ\" directory, just modify the line this way:

rompath=c:\r00mz\wareZ\

Ok, run the "ace.exe" file. Now press the right mouse button in the window.
Press the ace menu. Press file. Press Open. Now choose your favourite game.
Enjoy.

Note: you need the NEO-GEO.ROM and NG-SFIX.ROM roms zipped into the "neogeo.zip"
file in order to play Neogeo games. The neogeo.zip file must be placed in the
same directory of the other normal arcade game roms.

===================================
which games are supported/playable?
===================================

For a detailed list (all the rom names), run the emulator and press
"ace->file->CmproDat". Ace will create a file named "ACE vx.x.dat" in
the same directory where the emulator is placed. I think (I hope) that 
the list created with this method is self explainatory.

From version 1.9, also, ace is capable of reading Nebula ".dat" files. Those
files are nothing else than text files describing which roms do you need
to run a CPS2 game. This means that ace can run *any* CPS2 rom, if you give
it the correct rom description (via the dat file) and the correct roms (ahem...).
In order for the emulator to read and parse the .dat files, you have to set
up the path where the files are lying (datpath variable of the [general]
section of the ace.ini file - the already set up path should be ok, though,
unless you are Razoola trying to play gigawing). For a complete description 
of the .dat format, look at Nebula readme files.

Anyway, here is a more generic list of supported games:

-------------------------------------------------------------------
Game Type	Game Description			Romset Name
-------------------------------------------------------------------
CPS1		Final Fight World			ffight
CPS1		Street Fighter 2 World			sf2
CPS1		Megaman the Power Battle		megaman
CPS1		Three Wonders				3wonders
Neogeo		Goal Goal Goal				goal3x
Neogeo		King Of Fighters 94			kof94
Neogeo		Metal Slug 001				mslug
Neogeo		Metal Slug 002				mslug2
Neogeo		Metal Slug X				mslugx
Neogeo		Metal Slug 3 (nd)			mslug3nd
Neogeo		Neo Drift Out				neodrift
Neogeo		Puzzle Bobble				pbobble
Neogeo		Puzzle de Pon				puzzledp
Neogeo		Shock Troopers				shocktro
Neogeo		Super Sideckicks			ssideki
Neogeo		Super Dodgeball				sdodgeb
Neogeo		Viewpoint				viewpoin
Neogeo		Wakuwaku 7				wakuwak7
System 16	Shinobi					shinobi
System 18	Shadow Dancer				shdancer
-------------------------------------------------------------------

============
key settings
============

F3		insert one credit
F1 		start player 1 game
A,S,D,Z,X,C,	six buttons
P		pause
F11		load quickstate
F12		save quickstate
backspace	toggle speed throttling on/off
alt-F4		close ace (ever imagined that?)

===================
how can I spam you?
===================

friol@tiscalinet.it

suggestions, constructive criticism, request for features and bug reports
are well accepted. if you have a question that is not answered in this readme, 
write to me. otherwise don't bother and read with more attention please. ok?
one last thing: I have always been interested in local european culture,
but a question like "qual os codigos do emulador de neo geo?" doesn't make
much sense to me (neither if I was spanish, I guess). So please write in English
(or Italian, at least - chinese codepage is ok, but only Kanji charset...ehi, no
I was joking, ehi, noooooo....Last Blade 9 Neogeo CD ISO follows...)

========================
acknowledgements, thanks
========================

Dave Raingeard  for neogeo sprite zooming, system 16/18 sprites and listening
		to my suggestions sometimes 8-)

Dayvee		for proving that crappy code can lead to great programs.

Elsemi		for Nebula .dats, and his help with my questions (even if I find 
		the answer always before his replies 8-)

Logiqx		for the search of karma (100% romset compliancy)

Paul Leaman	for showing me the way.

Razoola		for cps2shock and his great work with CPS2 decryption (even if I don't
		approve his policy of releasing xors - but that is showbiz, you know)


Motorola 68000 32 Bit emulator Copyright 1998-2001 Mike Coates, Darren Olafson.
Multi-Z80 CPU emulator by Neil Bradley (neil@synthcom.com).
YM2151 (C) 1997,1998 Jarek Burczynski.
OKIM6295 ADPCM driver by Aaron Giles.
Qsound driver by Paul Leaman (paul@vortexcomputing.demon.co.uk)	and Miguel Angel Horna 
(mahorna@teleline.es).
YM2610 sound chip emulation & some other code from MAME.
